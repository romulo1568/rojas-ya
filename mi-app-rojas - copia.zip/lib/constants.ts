export const OPENING_DATE = new Date("2025-05-15T09:00:00")
